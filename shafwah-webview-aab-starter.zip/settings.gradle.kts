rootProject.name = "ShafwahWebView"
include(":app")